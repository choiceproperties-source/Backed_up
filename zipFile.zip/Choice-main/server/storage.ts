// This file is deprecated and should be removed
// All storage operations are handled directly through Supabase in routes.ts
// This was an attempt to create an abstraction layer that was never fully implemented

export interface IStorage {
  // Deprecated - use Supabase client directly in routes.ts
}
